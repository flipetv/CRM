/* Kit Comercial Plug & Play — conteúdo dos scripts.
   Edite este arquivo para trocar textos, roteiros e decisões. */

/* =====================================================================
   1. DADOS — edite os scripts aqui sem mexer na interface.
   ---------------------------------------------------------------------
   Campos de cada script:
     category   : "prospeccao" | "vendas" | "followup"
     group      : (opcional) subgrupo, ex. "objecoes"
     step       : (opcional) etapa de vendas 1–5 para o indicador de progresso
     title, summary, whenToUse, objective, objectiveNote, message,
     copyLabel  : (opcional) texto do botão copiar
     after      : orientação "O que fazer depois?"
     next       : árvore de decisão { question, options:[{label, to | href | sub}] }
                  to   = id de outro script
                  href = rota interna (ex. "#/crm")
                  sub  = nova pergunta { question, options }
   Campos [ENTRE COLCHETES] ficam destacados. [NOME], [SEU NOME] e
   [ESCRITÓRIO] são preenchidos automaticamente quando informados.
   ===================================================================== */

const NAV = [
  { id:"inicio",     label:"Início",     short:"Início",     emoji:"🏠", href:"#/" },
  { id:"prospeccao", label:"Prospecção", short:"Prospecção", emoji:"🚀", href:"#/prospeccao" },
  { id:"vendas",     label:"Vendas",     short:"Vendas",     emoji:"💬", href:"#/vendas" },
  { id:"followup",   label:"Follow-up",  short:"Follow-up",  emoji:"🔄", href:"#/followup" },
  { id:"crm",        label:"CRM",        short:"CRM",        emoji:"📋", href:"#/crm" },
  { id:"guia",       label:"Guia Rápido",short:"Guia",       emoji:"📚", href:"#/guia" }
];

const SALES_STEPS = ["Descoberta","Qualificação","Apresentação","Objeções","Fechamento"];

// Resposta comum depois de uma abordagem
const RESPONDEU = {
  question:"Qual foi a resposta?",
  options:[
    { label:"Demonstrou interesse", to:"v-qualificacao" },
    { label:"Perguntou o preço", to:"v-preco" },
    { label:"Disse que já tem contador", to:"o-ja-tenho" },
    { label:"Pediu para falar depois", to:"o-momento" }
  ]
};

const SCRIPTS = {
  /* ---------------- PROSPECÇÃO ---------------- */
  "p-primeiro-contato": {
    category:"prospeccao",
    title:"Primeiro contato",
    summary:"Para abordar uma empresa pela primeira vez.",
    whenToUse:"Use este roteiro quando você estiver entrando em contato com uma empresa que ainda não conhece seu escritório.",
    objective:"Iniciar uma conversa.",
    objectiveNote:"Não tente vender tudo na primeira mensagem.",
    message:"Olá, [NOME]. Tudo bem? Aqui é [SEU NOME], do escritório [ESCRITÓRIO].\n\nEstou entrando em contato porque identifiquei uma oportunidade que pode fazer sentido para empresas como a sua.\n\nPosso te fazer uma pergunta rápida?",
    after:"Se a pessoa responder positivamente, avance para a próxima etapa. Se não houver resposta em 1 ou 2 dias, faça o primeiro follow-up.",
    next:{ question:"O cliente respondeu?", options:[
      { label:"Ele respondeu", yes:true, sub:RESPONDEU },
      { label:"Ele não respondeu", to:"f-primeiro" }
    ]}
  },
  "p-interessado": {
    category:"prospeccao",
    title:"Lead interessado",
    summary:"Para continuar uma conversa iniciada.",
    whenToUse:"O lead já respondeu e mostrou abertura para conversar.",
    objective:"Transformar interesse em uma conversa de diagnóstico.",
    objectiveNote:"Faça perguntas simples, fáceis de responder pelo celular.",
    message:"Que bom, [NOME]! Para eu não te passar nada genérico, queria entender um pouco melhor a sua empresa.\n\nHoje vocês já têm contador ou cuidam dessa parte internamente? E qual é o ramo de atuação?",
    after:"Com as respostas em mãos, siga para a descoberta.",
    next:{ question:"Como a conversa evoluiu?", options:[
      { label:"Respondeu às perguntas", to:"v-descoberta" },
      { label:"Perguntou o preço", to:"v-preco" },
      { label:"Parou de responder", to:"f-primeiro" }
    ]}
  },
  "p-reativacao": {
    category:"prospeccao",
    title:"Reativação",
    summary:"Para voltar a falar com um potencial cliente antigo.",
    whenToUse:"Você já conversou com essa empresa no passado, mas a negociação não avançou.",
    objective:"Reabrir a conversa sem cobrar uma decisão.",
    objectiveNote:"Lembre quem você é e faça uma pergunta aberta.",
    message:"Oi, [NOME], tudo bem? Aqui é [SEU NOME], do [ESCRITÓRIO]. A gente conversou há um tempo sobre a contabilidade da sua empresa.\n\nEstou retomando contato com algumas empresas e lembrei de você. Como estão as coisas por aí? Faz sentido retomarmos aquela conversa?",
    after:"Se a pessoa topar, volte para a descoberta: o cenário dela pode ter mudado.",
    next:{ question:"O cliente respondeu?", options:[
      { label:"Ele respondeu", yes:true, sub:{ question:"Qual foi a resposta?", options:[
        { label:"Quer retomar a conversa", to:"v-descoberta" },
        { label:"Já fechou com outro contador", to:"o-ja-tenho" },
        { label:"Ainda não é o momento", to:"o-momento" }
      ]}},
      { label:"Ele não respondeu", to:"f-segundo" }
    ]}
  },
  "p-indicacao": {
    category:"prospeccao",
    title:"Indicação",
    summary:"Para abordar alguém indicado por um cliente ou parceiro.",
    whenToUse:"Um cliente ou parceiro indicou seu escritório para alguém.",
    objective:"Usar a confiança da indicação para abrir a conversa.",
    objectiveNote:"Cite quem indicou logo na primeira linha.",
    message:"Olá, [NOME]! Aqui é [SEU NOME], do [ESCRITÓRIO]. O(a) [QUEM INDICOU] me passou seu contato e comentou que talvez eu pudesse te ajudar com a contabilidade da sua empresa.\n\nVocê tem uns minutinhos essa semana para uma conversa rápida?",
    after:"Agradeça a quem indicou, independentemente do resultado.",
    next:{ question:"O cliente respondeu?", options:[
      { label:"Ele respondeu", yes:true, sub:{ question:"Qual foi a resposta?", options:[
        { label:"Topou conversar", to:"v-descoberta" },
        { label:"Perguntou o preço", to:"v-preco" },
        { label:"Pediu para falar depois", to:"o-momento" }
      ]}},
      { label:"Ele não respondeu", to:"f-primeiro" }
    ]}
  },

  /* ---------------- VENDAS ---------------- */
  "v-descoberta": {
    category:"vendas", step:1,
    title:"Descoberta",
    summary:"Entender o cenário do potencial cliente.",
    whenToUse:"No começo da conversa, antes de falar do seu serviço.",
    objective:"Entender o cenário do potencial cliente.",
    objectiveNote:"Ouça mais do que fala. Anote o que ele disser.",
    message:"Para eu entender melhor o seu cenário, posso te fazer algumas perguntas rápidas?\n\n1. Qual é o ramo da empresa e há quanto tempo ela existe?\n2. Hoje quem cuida da parte contábil e fiscal?\n3. O que mais te incomoda nessa parte hoje?",
    after:"Registre as respostas no CRM. Elas vão guiar a sua apresentação.",
    next:{ question:"O que você descobriu?", options:[
      { label:"Tem uma necessidade clara", to:"v-qualificacao" },
      { label:"Já tem contador e parece satisfeito", to:"o-ja-tenho" },
      { label:"Parou de responder", to:"f-primeiro" }
    ]}
  },
  "v-qualificacao": {
    category:"vendas", step:2,
    title:"Qualificação",
    summary:"Identificar necessidade, momento e perfil.",
    whenToUse:"O lead mostrou interesse e você precisa saber se ele tem o perfil que seu escritório atende.",
    objective:"Identificar necessidade, momento e perfil.",
    objectiveNote:"Sem essas respostas, qualquer proposta é um chute.",
    message:"Obrigado por compartilhar, [NOME]. Só mais algumas coisas para eu te indicar o caminho certo:\n\n• Qual é o regime tributário da empresa hoje (Simples, Presumido ou Real)?\n• Quantos funcionários vocês têm?\n• Você pensa em resolver isso agora ou mais para frente?",
    after:"Se a empresa tem o perfil que você atende e quer resolver logo, apresente a solução.",
    next:{ question:"O lead está qualificado?", options:[
      { label:"Sim, tem perfil e quer resolver agora", to:"v-apresentacao" },
      { label:"Tem perfil, mas não é o momento", to:"o-momento" },
      { label:"Perguntou o preço", to:"v-preco" }
    ]}
  },
  "v-apresentacao": {
    category:"vendas", step:3,
    title:"Apresentação",
    summary:"Mostrar a solução adequada.",
    whenToUse:"Você já entendeu o cenário e o lead está qualificado.",
    objective:"Mostrar a solução ligada ao que o cliente falou.",
    objectiveNote:"Conecte cada ponto a um problema que ele mencionou.",
    message:"Pelo que você me contou, [NOME], o principal ponto hoje é [PROBLEMA DO CLIENTE].\n\nNo [ESCRITÓRIO], a gente cuida disso assim:\n• [COMO VOCÊ RESOLVE]\n• [O QUE ESTÁ INCLUSO]\n• [DIFERENCIAL DO SEU ESCRITÓRIO]\n\nFaz sentido para o que você precisa?",
    after:"Termine sempre com uma pergunta. Ela mostra se o cliente está pronto para avançar.",
    next:{ question:"Como o cliente reagiu?", options:[
      { label:"Gostou e quer avançar", to:"v-fechamento" },
      { label:"Apresentou uma objeção", href:"#/vendas/objecoes" },
      { label:"Pediu uma proposta", to:"o-proposta" }
    ]}
  },
  "v-fechamento": {
    category:"vendas", step:5,
    title:"Fechamento",
    summary:"Conduzir para a decisão.",
    whenToUse:"O cliente concordou com a solução e está pronto para decidir.",
    objective:"Conduzir para a decisão com clareza.",
    objectiveNote:"Deixe o próximo passo simples e com data.",
    message:"Ótimo, [NOME]! Então o próximo passo é bem simples:\n\n1. Te envio o contrato para assinatura\n2. Você me passa os acessos e documentos da empresa\n3. A gente cuida da transição com o contador atual\n\nPosso te enviar o contrato hoje?",
    after:"Depois do sim, mova o lead para “Fechado” no CRM e combine a data de início.",
    next:{ question:"O cliente fechou?", options:[
      { label:"Fechou!", yes:true, href:"#/crm" },
      { label:"Pediu para pensar", to:"o-pensar" },
      { label:"Achou caro", to:"o-caro" }
    ]}
  },
  "v-preco": {
    category:"vendas",
    title:"Cliente perguntou o preço",
    summary:"Quando pedem valor antes de você entender a necessidade.",
    whenToUse:"O cliente pergunta “quanto custa?” logo no começo da conversa.",
    objective:"Responder sem jogar um número solto.",
    objectiveNote:"Mostre que o valor depende do cenário e peça permissão para perguntar.",
    message:"Claro, [NOME]! O valor depende de alguns pontos, como o regime tributário, o volume de notas e o número de funcionários.\n\nPara eu te passar um valor justo e sem surpresa depois, posso te fazer 3 perguntas rápidas?",
    after:"Com as respostas, você consegue indicar o plano certo ou montar a proposta.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Topou responder", to:"v-qualificacao" },
      { label:"Insistiu em receber o valor", to:"o-proposta" },
      { label:"Não respondeu", to:"f-primeiro" }
    ]}
  },

  /* ---------------- OBJEÇÕES ---------------- */
  "o-caro": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Está caro”",
    summary:"O cliente achou o valor alto.",
    whenToUse:"O cliente disse que o valor está alto ou comparou com outro preço.",
    objective:"Não entrar imediatamente em uma disputa de preço.",
    objectiveNote:"Volte a conversa para o problema que ele quer resolver.",
    message:"Entendo. Antes de falarmos apenas sobre preço, posso entender melhor o que você está buscando resolver hoje? Assim consigo te mostrar se a nossa solução realmente faz sentido para sua empresa.",
    copyLabel:"Copiar resposta",
    after:"Se ele explicar o que busca, reforce como seu serviço resolve exatamente isso.",
    next:{ question:"Como o cliente reagiu?", options:[
      { label:"Explicou o que busca", to:"v-apresentacao" },
      { label:"Disse que vai pensar", to:"o-pensar" },
      { label:"Não respondeu", to:"f-primeiro" }
    ]}
  },
  "o-pensar": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Vou pensar”",
    summary:"O cliente pediu tempo.",
    whenToUse:"O cliente gostou da conversa, mas pediu para pensar antes de decidir.",
    objective:"Descobrir o que está por trás do “vou pensar”.",
    objectiveNote:"Normalmente existe uma dúvida que ele não falou.",
    message:"Claro, [NOME], faz todo sentido pensar com calma.\n\nSó para eu te ajudar nessa análise: ficou alguma dúvida sobre o serviço ou o ponto principal é o investimento?",
    copyLabel:"Copiar resposta",
    after:"Se ele disser qual é a dúvida, responda só ela. Se não responder, faça o follow-up em alguns dias.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Tinha uma dúvida sobre o serviço", to:"v-apresentacao" },
      { label:"O ponto é o preço", to:"o-caro" },
      { label:"Não respondeu", to:"f-pensar" }
    ]}
  },
  "o-socio": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Preciso falar com meu sócio”",
    summary:"A decisão depende de outra pessoa.",
    whenToUse:"O cliente precisa alinhar a decisão com sócio, cônjuge ou outra pessoa.",
    objective:"Participar da conversa com quem decide.",
    objectiveNote:"Ofereça ajuda concreta para facilitar o alinhamento.",
    message:"Perfeito, [NOME]. Decisão importante tem que ser alinhada mesmo.\n\nSe ajudar, posso preparar um resumo curto para você mostrar ao seu sócio, ou a gente marca uma conversa rápida com vocês dois. O que fica melhor?",
    copyLabel:"Copiar resposta",
    after:"Combine uma data para o retorno antes de encerrar a conversa.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Marcou conversa com o sócio", to:"v-apresentacao" },
      { label:"Pediu o resumo", to:"o-proposta" },
      { label:"Não respondeu mais", to:"f-socio" }
    ]}
  },
  "o-ja-tenho": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Já tenho contador”",
    summary:"O cliente já é atendido por outro escritório.",
    whenToUse:"O cliente disse que já tem um contador.",
    objective:"Abrir espaço para comparação sem criticar o contador atual.",
    objectiveNote:"Nunca fale mal do concorrente.",
    message:"Que bom que vocês já têm alguém cuidando disso, [NOME]!\n\nPosso te perguntar uma coisa? De 0 a 10, que nota você daria para o atendimento que recebe hoje? Se não for 10, talvez eu consiga te mostrar outra forma de fazer.",
    copyLabel:"Copiar resposta",
    after:"Se ele apontar algum incômodo, investigue esse ponto na descoberta.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Apontou algum incômodo", to:"v-descoberta" },
      { label:"Está satisfeito", href:"#/crm" }
    ]}
  },
  "o-proposta": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Me manda uma proposta”",
    summary:"O cliente quer tudo por escrito.",
    whenToUse:"O cliente pede uma proposta antes de conversar sobre o cenário dele.",
    objective:"Garantir uma proposta personalizada e um motivo para conversar de novo.",
    objectiveNote:"Proposta sem informação vira comparação de preço.",
    message:"Mando sim, [NOME]! Para a proposta sair certinha para a sua realidade, preciso confirmar 3 coisas rapidinho:\n\n• Regime tributário\n• Quantidade média de notas por mês\n• Número de funcionários\n\nConsegue me passar?",
    copyLabel:"Copiar resposta",
    after:"Ao enviar a proposta, já combine um dia para conversarem sobre ela.",
    next:{ question:"E agora?", options:[
      { label:"Enviei a proposta", to:"f-proposta" },
      { label:"Ele não passou as informações", to:"f-primeiro" }
    ]}
  },
  "o-momento": {
    category:"vendas", group:"objecoes", step:4,
    title:"“Agora não é o momento”",
    summary:"O cliente quer deixar para depois.",
    whenToUse:"O cliente tem interesse, mas diz que agora não dá.",
    objective:"Sair com uma data combinada para voltar a falar.",
    objectiveNote:"Um “depois” sem data costuma virar “nunca”.",
    message:"Entendo, [NOME]. Sem problema nenhum.\n\nSó para eu me organizar: quando você acha que seria um bom momento para voltarmos a conversar? Posso te chamar em [MÊS]?",
    copyLabel:"Copiar resposta",
    after:"Registre a data combinada no CRM, no campo “Próximo contato”.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Combinou uma data", href:"#/crm" },
      { label:"Não definiu", to:"f-segundo" }
    ]}
  },

  /* ---------------- FOLLOW-UP ---------------- */
  "f-primeiro": {
    category:"followup",
    title:"Primeiro follow-up",
    summary:"Quando o cliente não respondeu.",
    whenToUse:"O lead recebeu sua primeira mensagem e não respondeu depois de 1 ou 2 dias.",
    objective:"Retomar a atenção sem pressionar.",
    objectiveNote:"Mensagem curta e fácil de responder.",
    message:"Oi, [NOME]! Passando só para não deixar minha mensagem se perder por aqui.\n\nSei que a rotina de quem tem empresa é corrida. Posso te fazer aquela pergunta rápida?",
    after:"Se ele responder, siga a conversa. Se continuar em silêncio, espere alguns dias e envie o segundo follow-up.",
    next:{ question:"O cliente respondeu?", options:[
      { label:"Ele respondeu", yes:true, sub:RESPONDEU },
      { label:"Ele não respondeu", to:"f-segundo" }
    ]}
  },
  "f-segundo": {
    category:"followup",
    title:"Segundo follow-up",
    summary:"Quando o cliente continua sem responder.",
    whenToUse:"O lead continua sem responder depois do primeiro follow-up.",
    objective:"Encerrar o ciclo com elegância e deixar a porta aberta.",
    objectiveNote:"Dar uma saída leve costuma gerar mais respostas do que insistir.",
    message:"Oi, [NOME]. Imagino que agora não seja o melhor momento, e tudo bem.\n\nVou deixar meu contato por aqui. Se em algum momento quiser uma segunda opinião sobre a contabilidade da sua empresa, é só me chamar.\n\nPosso te procurar de novo daqui a alguns meses?",
    after:"Sem resposta? Mova o lead para “Perdido” ou agende uma reativação no CRM.",
    next:{ question:"O cliente respondeu?", options:[
      { label:"Ele respondeu", yes:true, sub:{ question:"Qual foi a resposta?", options:[
        { label:"Demonstrou interesse", to:"v-qualificacao" },
        { label:"Pode chamar mais para frente", to:"o-momento" }
      ]}},
      { label:"Ele não respondeu", href:"#/crm" }
    ]}
  },
  "f-proposta": {
    category:"followup",
    title:"Após enviar proposta",
    summary:"Quando o cliente recebeu a proposta.",
    whenToUse:"O cliente recebeu a proposta e ainda não deu retorno.",
    objective:"Trazer a proposta de volta para a conversa.",
    objectiveNote:"Pergunte sobre dúvidas, não sobre a decisão.",
    message:"Oi, [NOME]! Conseguiu dar uma olhada na proposta que te enviei?\n\nSe tiver qualquer dúvida ou algo que queira ajustar, me fala que eu te explico por aqui mesmo.",
    after:"Se ele levantar uma objeção, use o roteiro correspondente.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Quer fechar", to:"v-fechamento" },
      { label:"Achou caro", to:"o-caro" },
      { label:"Vai pensar", to:"o-pensar" },
      { label:"Não respondeu", to:"f-segundo" }
    ]}
  },
  "f-pensar": {
    category:"followup",
    title:"“Vou pensar”",
    summary:"Quando o cliente pediu tempo.",
    whenToUse:"O cliente pediu um tempo para pensar e alguns dias já se passaram.",
    objective:"Retomar sem pressionar e ajudar na decisão.",
    objectiveNote:"Ofereça ajuda, não cobrança.",
    message:"Oi, [NOME], tudo bem? Fiquei de te dar um tempinho para pensar sobre a nossa conversa.\n\nConseguiu avaliar? Se quiser, posso tirar alguma dúvida que tenha ficado.",
    after:"Se ele ainda estiver em dúvida, descubra qual é o ponto que falta.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Decidiu avançar", to:"v-fechamento" },
      { label:"Ainda está em dúvida", to:"o-pensar" },
      { label:"Não respondeu", to:"f-segundo" }
    ]}
  },
  "f-socio": {
    category:"followup",
    title:"“Vou falar com meu sócio”",
    summary:"Quando a decisão depende de outra pessoa.",
    whenToUse:"A decisão depende de um sócio e você ainda não teve retorno.",
    objective:"Saber como está a decisão e se oferecer para ajudar.",
    objectiveNote:"Proponha falar com os dois ao mesmo tempo.",
    message:"Oi, [NOME]! Conseguiu conversar com seu sócio sobre a nossa proposta?\n\nSe ajudar, posso participar de uma conversa rápida com vocês dois para tirar as dúvidas direto.",
    after:"Se marcarem a conversa, prepare uma apresentação focada nas dúvidas do sócio.",
    next:{ question:"Qual foi a resposta?", options:[
      { label:"Marcaram uma conversa", to:"v-apresentacao" },
      { label:"Decidiram avançar", to:"v-fechamento" },
      { label:"Não respondeu", to:"f-segundo" }
    ]}
  }
};

// Listas exibidas em cada tela (ordem e textos dos cards)
const MENUS = {
  prospeccao:[
    { to:"p-primeiro-contato" },
    { to:"f-primeiro", title:"Lead que não respondeu", summary:"Para fazer o primeiro follow-up." },
    { to:"p-interessado" },
    { to:"p-reativacao" },
    { to:"p-indicacao" }
  ],
  vendas:[
    { to:"v-descoberta", n:"01" },
    { to:"v-qualificacao", n:"02" },
    { to:"v-apresentacao", n:"03" },
    { href:"#/vendas/objecoes", n:"04", title:"Objeções", summary:"Responder às principais objeções." },
    { to:"v-fechamento", n:"05" }
  ],
  vendasExtra:[ { to:"v-preco" } ],
  objecoes:["o-caro","o-pensar","o-socio","o-ja-tenho","o-proposta","o-momento"],
  followup:[
    { to:"f-primeiro" }, { to:"f-segundo" }, { to:"f-proposta" }, { to:"f-pensar" }, { to:"f-socio" }
  ]
};

const STAGES = [
  { id:"novo", label:"Novo" },
  { id:"contatado", label:"Contatado" },
  { id:"conversando", label:"Conversando" },
  { id:"qualificado", label:"Qualificado" },
  { id:"proposta", label:"Proposta" },
  { id:"fechado", label:"Fechado" },
  { id:"perdido", label:"Perdido" }
];
