/* Kit Comercial Plug & Play — lógica da aplicação.
   Depende de js/data.js (carregado antes). */

/* =====================================================================
   2. UTILITÁRIOS
   ===================================================================== */
const $ = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const pad = n => String(n).padStart(2,"0");
const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };
const fmtDate = iso => { if(!iso) return ""; const [y,m,d]=iso.split("-"); return `${d}/${m}`; };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,7);

const storage = {
  get(k, d){ try{ const v=localStorage.getItem(k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} },
  remove(k){ try{ localStorage.removeItem(k); }catch(e){} }
};
const KEYS = { leads:"kcpp.leads.v1", prefs:"kcpp.prefs.v1", col:"kcpp.crmcol.v1" };

/* =====================================================================
   3. ESTADO
   ===================================================================== */
const state = {
  leads: storage.get(KEYS.leads, []),
  prefs: storage.get(KEYS.prefs, { seuNome:"", escritorio:"" }),
  crmCol: storage.get(KEYS.col, "novo"),
  contactName: "" // nome do contato da conversa atual (não salvo)
};
const saveLeads = () => storage.set(KEYS.leads, state.leads);
const savePrefs = () => storage.set(KEYS.prefs, state.prefs);

/* =====================================================================
   4. COMPONENTES
   ===================================================================== */
function Nav(active){
  const item = n => `<li><a href="${n.href}" ${n.id===active?'aria-current="page"':''}><span class="ico" aria-hidden="true">${n.emoji}</span><span>{{L}}</span></a></li>`;
  $("#sideNav").innerHTML = NAV.map(n => item(n).replace("{{L}}", esc(n.label))).join("");
  $("#bottomNav").innerHTML = NAV.map(n => item(n).replace("{{L}}", esc(n.short))).join("");
}

function Header(title, subtitle){
  return `<header class="page-head"><h1 tabindex="-1">${title}</h1>${subtitle?`<p>${subtitle}</p>`:""}</header>`;
}

function Breadcrumbs(items){
  return `<nav aria-label="Você está em"><ol class="crumbs">${items.map((it,i)=> i<items.length-1
    ? `<li><a href="${it.href}">${esc(it.label)}</a></li>`
    : `<li aria-current="page">${esc(it.label)}</li>`).join("")}</ol></nav>`;
}

function SituationCard(item){
  const s = item.to ? SCRIPTS[item.to] : null;
  const title = item.title || s?.title || "";
  const summary = item.summary || s?.summary || "";
  const href = item.href || `#/s/${item.to}`;
  return `<li><a class="sit" href="${href}">
    ${item.n?`<span class="num" aria-hidden="true">${item.n}</span>`:""}
    <span class="txt"><strong>${esc(title)}</strong><span class="sub">${esc(summary)}</span></span>
    <span class="chev" aria-hidden="true">›</span></a></li>`;
}

function ProgressIndicator(step){
  return `<ol class="progress" aria-label="Etapa ${step} de ${SALES_STEPS.length}: ${SALES_STEPS[step-1]}">${SALES_STEPS.map((l,i)=>{
    const cls = i+1<step ? "done" : i+1===step ? "cur" : "";
    return `<li class="${cls}"><span class="bar"></span><span class="lbl">${esc(l)}</span></li>`;
  }).join("")}</ol>`;
}

function EmptyState({emoji, title, text, action}){
  return `<div class="empty"><div class="emo" aria-hidden="true">${emoji}</div><h2>${title}</h2><p>${text}</p>${action||""}</div>`;
}

// Preenche campos conhecidos e destaca os que faltam
function fillMessage(msg){
  let t = msg;
  if(state.prefs.seuNome) t = t.replaceAll("[SEU NOME]", state.prefs.seuNome);
  if(state.prefs.escritorio) t = t.replaceAll("[ESCRITÓRIO]", state.prefs.escritorio);
  if(state.contactName.trim()) t = t.replaceAll("[NOME]", state.contactName.trim());
  return t;
}
const messageHTML = t => esc(t).replace(/\[([^\]]+)\]/g, '<mark>[$1]</mark>');

async function copyText(text){
  try{
    if(navigator.clipboard && window.isSecureContext){ await navigator.clipboard.writeText(text); return true; }
  }catch(e){}
  try{
    const ta=document.createElement("textarea");
    ta.value=text; ta.setAttribute("readonly",""); ta.style.position="fixed"; ta.style.opacity="0";
    document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
    const ok=document.execCommand("copy"); ta.remove(); return ok;
  }catch(e){ return false; }
}

function bindCopyButton(btn, getText, label){
  let timer;
  btn.addEventListener("click", async () => {
    const ok = await copyText(getText());
    if(ok){
      btn.classList.add("done");
      btn.innerHTML = "✓ Copiado!";
      toast(label.includes("resposta") ? "✓ Resposta copiada!" : "✓ Mensagem copiada!");
      clearTimeout(timer);
      timer = setTimeout(() => { btn.classList.remove("done"); btn.innerHTML = `📋 ${esc(label)}`; }, 2200);
    } else {
      toast("Não foi possível copiar. Selecione o texto e copie manualmente.");
    }
  });
}

let toastTimer;
function toast(msg){
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> el.classList.remove("show"), 2200);
}

/* ---------- Modal ---------- */
function openModal({ title, body, onMount, onClose }){
  const prev = document.activeElement;
  const root = $("#modalRoot");
  root.innerHTML = `<div class="modal-wrap"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="mTitle">
    <div class="modal-head"><h2 id="mTitle">${title}</h2><button class="modal-x" type="button" aria-label="Fechar">✕</button></div>
    ${body}</div></div>`;
  const wrap = $(".modal-wrap", root), dlg = $(".modal", root);
  const close = () => { root.innerHTML=""; document.removeEventListener("keydown", onKey); prev && prev.focus && prev.focus(); onClose && onClose(); };
  const onKey = e => {
    if(e.key==="Escape"){ close(); }
    if(e.key==="Tab"){
      const f = $$("button, [href], input, select, textarea", dlg).filter(x=>!x.disabled);
      if(!f.length) return;
      if(e.shiftKey && document.activeElement===f[0]){ e.preventDefault(); f[f.length-1].focus(); }
      else if(!e.shiftKey && document.activeElement===f[f.length-1]){ e.preventDefault(); f[0].focus(); }
    }
  };
  document.addEventListener("keydown", onKey);
  wrap.addEventListener("mousedown", e => { if(e.target===wrap) close(); });
  $(".modal-x", dlg).addEventListener("click", close);
  onMount && onMount(dlg, close);
  const first = $("input, textarea, select", dlg) || $(".modal-actions .btn", dlg) || $(".modal-x", dlg);
  first && first.focus();
  return close;
}

function confirmDialog(text, confirmLabel, onYes){
  openModal({
    title:"Tem certeza?",
    body:`<p style="margin:0 0 18px;color:var(--ink-2)">${text}</p>
      <div class="modal-actions"><button class="btn btn-ghost" type="button" data-no>Cancelar</button><button class="btn btn-danger" type="button" data-yes>${confirmLabel}</button></div>`,
    onMount(dlg, close){
      $("[data-no]",dlg).addEventListener("click", close);
      $("[data-yes]",dlg).addEventListener("click", ()=>{ close(); onYes(); });
    }
  });
}

/* ---------- Formulário de lead ---------- */
function openLeadForm(lead, defaults={}){
  const isEdit = !!lead;
  const l = lead || { name:"", company:"", phone:"", note:"", next:"", stage:"novo", ...defaults };
  openModal({
    title: isEdit ? "Editar lead" : "Adicionar lead",
    body:`<form novalidate>
      <div class="field"><label for="fName">Nome</label><input id="fName" name="name" autocomplete="off" value="${esc(l.name)}" required><span class="err" id="fErr" hidden>Informe o nome do lead.</span></div>
      <div class="field"><label for="fCompany">Empresa <span class="opt">(opcional)</span></label><input id="fCompany" name="company" autocomplete="off" value="${esc(l.company)}"></div>
      <div class="row2">
        <div class="field"><label for="fPhone">WhatsApp <span class="opt">(opcional)</span></label><input id="fPhone" name="phone" type="tel" inputmode="tel" placeholder="(11) 99999-9999" value="${esc(l.phone)}"></div>
        <div class="field"><label for="fNext">Próximo contato <span class="opt">(opcional)</span></label><input id="fNext" name="next" type="date" value="${esc(l.next)}"></div>
      </div>
      <div class="field"><label for="fStage">Etapa</label><select id="fStage" name="stage">${STAGES.map(s=>`<option value="${s.id}" ${s.id===l.stage?"selected":""}>${s.label}</option>`).join("")}</select></div>
      <div class="field"><label for="fNote">Observação <span class="opt">(opcional)</span></label><textarea id="fNote" name="note" placeholder="Ex.: prefere contato à tarde">${esc(l.note)}</textarea></div>
      <div class="modal-actions"><button class="btn btn-ghost" type="button" data-cancel>Cancelar</button><button class="btn btn-primary" type="submit">${isEdit?"Salvar alterações":"Adicionar lead"}</button></div>
    </form>`,
    onMount(dlg, close){
      $("[data-cancel]",dlg).addEventListener("click", close);
      $("form",dlg).addEventListener("submit", e => {
        e.preventDefault();
        const fd = Object.fromEntries(new FormData(e.target).entries());
        if(!fd.name.trim()){ $("#fErr",dlg).hidden=false; $("#fName",dlg).focus(); return; }
        const data = { name:fd.name.trim(), company:fd.company.trim(), phone:fd.phone.trim(), next:fd.next, stage:fd.stage, note:fd.note.trim() };
        if(isEdit){ Object.assign(lead, data); toast("✓ Alterações salvas"); }
        else { state.leads.unshift({ id:uid(), createdAt:Date.now(), ...data }); toast("✓ Lead adicionado"); }
        state.crmCol = data.stage; storage.set(KEYS.col, state.crmCol);
        saveLeads(); close();
        if(location.hash.startsWith("#/crm")) render(); else location.hash = "#/crm";
      });
    }
  });
}

/* ---------- Árvore de decisão ---------- */
function DecisionPanel(el, node, history=[]){
  const optTarget = o => o.sub ? "Escolher a resposta" : o.to ? `Abre: ${SCRIPTS[o.to]?.title || ""}` : o.href==="#/crm" ? "Atualizar no CRM" : o.href?.includes("objecoes") ? "Escolher a objeção" : "";
  el.innerHTML = `<div class="dstep">
    <p class="dq" id="dq">${esc(node.question)}</p>
    <div class="dopts ${node.options.length===2?"two":""}" role="group" aria-labelledby="dq">
      ${node.options.map((o,i)=>`<button type="button" class="dopt ${o.yes?"yes":""}" data-i="${i}">${esc(o.label)}<span class="to">${esc(optTarget(o))}</span></button>`).join("")}
    </div>
    ${history.length?`<button type="button" class="btn-link" data-back style="margin-top:10px">← Voltar à pergunta anterior</button>`:""}
  </div>`;
  $$(".dopt", el).forEach(b => b.addEventListener("click", () => {
    const o = node.options[+b.dataset.i];
    if(o.sub){ DecisionPanel(el, o.sub, [...history, node]); $(".dopt", el)?.focus(); }
    else if(o.to){ location.hash = `#/s/${o.to}`; }
    else if(o.href){ location.hash = o.href; }
  }));
  const back = $("[data-back]", el);
  back && back.addEventListener("click", () => { DecisionPanel(el, history[history.length-1], history.slice(0,-1)); $(".dopt", el)?.focus(); });
}

/* =====================================================================
   5. TELAS
   ===================================================================== */
const pages = {};

pages.home = () => {
  const today = todayISO();
  const due = state.leads.filter(l => l.next && l.next <= today && !["fechado","perdido"].includes(l.stage)).length;
  const cards = [
    { emoji:"🚀", title:"Prospectar", text:"Encontre e aborde novos potenciais clientes.", cta:"Começar prospecção", href:"#/prospeccao" },
    { emoji:"💬", title:"Vender", text:"Conduza conversas e transforme oportunidades em clientes.", cta:"Abrir scripts de vendas", href:"#/vendas" },
    { emoji:"🔄", title:"Follow-up", text:"Saiba o que fazer quando o cliente não responde ou está pensando.", cta:"Ver follow-ups", href:"#/followup" },
    { emoji:"📋", title:"Organizar", text:"Acompanhe seus leads e saiba quem precisa de atenção.", cta:"Abrir CRM", href:"#/crm" }
  ];
  return `
  <section class="home-hero">
    <span class="kicker">Kit Comercial Plug &amp; Play</span>
    <h1 tabindex="-1">Seu comercial começa aqui.</h1>
    <p>Escolha o que você precisa fazer agora.</p>
  </section>
  ${due?`<a class="attention" href="#/crm"><span class="count">${due}</span><span><strong>${due===1?"1 lead precisa":"" + due + " leads precisam"} de contato hoje</strong><span>Abra o CRM para ver quem chamar.</span></span></a>`:""}
  <div class="actions">
    ${cards.map(c=>`<a class="action" href="${c.href}">
      <span class="emo" aria-hidden="true">${c.emoji}</span>
      <h2>${c.title}</h2><p>${c.text}</p>
      <span class="btn btn-primary">${c.cta}</span></a>`).join("")}
  </div>`;
};

pages.prospeccao = () => `
  ${Header("🚀 Prospecção","Escolha a situação que mais se aproxima do seu momento.")}
  <ul class="sit-list">${MENUS.prospeccao.map(SituationCard).join("")}</ul>`;

pages.vendas = () => `
  ${Header("💬 Vendas","Encontre rapidamente o roteiro certo para cada momento da conversa.")}
  <ul class="sit-list">${MENUS.vendas.map(SituationCard).join("")}</ul>
  <h2 class="group-title">Situações comuns</h2>
  <ul class="sit-list">${MENUS.vendasExtra.map(SituationCard).join("")}</ul>`;

pages.objecoes = () => `
  <a class="back" href="#/vendas">← Voltar para Vendas</a>
  ${ProgressIndicator(4)}
  ${Header("Objeções","Responda sem pressionar e sem entrar em disputa.")}
  <p class="question">Qual objeção o cliente apresentou?</p>
  <div class="obj-grid">${MENUS.objecoes.map(id=>`<a class="obj" href="#/s/${id}">${esc(SCRIPTS[id].title)}</a>`).join("")}</div>`;

pages.followup = () => `
  ${Header("🔄 Follow-up","Não deixe oportunidades morrerem por falta de acompanhamento.")}
  <ul class="sit-list">${MENUS.followup.map(SituationCard).join("")}</ul>`;

pages.script = (id) => {
  const s = SCRIPTS[id];
  if(!s) return EmptyState({emoji:"🔎", title:"Roteiro não encontrado", text:"Esse roteiro não existe ou foi renomeado.", action:`<a class="btn btn-primary" href="#/">Voltar ao início</a>`});
  const cat = NAV.find(n=>n.id===s.category);
  const crumbs = [{label:"Início",href:"#/"},{label:cat.label,href:cat.href}];
  if(s.group==="objecoes") crumbs.push({label:"Objeções",href:"#/vendas/objecoes"});
  crumbs.push({label:s.title.replace(/[“”]/g,"")});
  const copyLabel = s.copyLabel || "Copiar mensagem";
  return `<article class="script">
    ${Breadcrumbs(crumbs)}
    ${s.step?ProgressIndicator(s.step):""}
    <h1 tabindex="-1">${esc(s.title)}</h1>

    <section class="block"><h2>Quando usar</h2><p>${esc(s.whenToUse)}</p></section>

    <section class="block"><h2>🎯 Objetivo desta etapa</h2>
      <div class="objective"><strong>${esc(s.objective)}</strong>${s.objectiveNote?`<p>${esc(s.objectiveNote)}</p>`:""}</div>
    </section>

    <section class="block"><h2>💬 ${s.copyLabel?"Resposta sugerida":"Mensagem"}</h2>
      <div class="chat">
        ${s.message.includes("[NOME]")?`<div class="chat-to"><label for="toName">Para:</label><input id="toName" placeholder="Nome do contato (opcional)" autocomplete="off" value="${esc(state.contactName)}"></div>`:""}
        <div class="bubble" id="bubble"></div>
        <p class="ph-hint" id="phHint" hidden>Troque os campos destacados antes de enviar.</p>
        <button class="btn btn-primary copy" id="copyBtn" type="button">📋 ${esc(copyLabel)}</button>
      </div>
    </section>

    <section class="block"><h2>O que fazer depois?</h2><p>${esc(s.after)}</p>
      ${s.next?`<div class="decision" id="decision"></div>`:""}
    </section>

    <div class="after-actions">
      <button class="btn btn-ghost" type="button" id="toCrm">＋ Registrar lead no CRM</button>
    </div>
  </article>`;
};
pages.script.mount = (id) => {
  const s = SCRIPTS[id]; if(!s) return;
  const bubble = $("#bubble"), hint = $("#phHint");
  const paint = () => {
    const t = fillMessage(s.message);
    bubble.innerHTML = messageHTML(t);
    hint.hidden = !/\[[^\]]+\]/.test(t);
  };
  paint();
  const inp = $("#toName");
  inp && inp.addEventListener("input", e => { state.contactName = e.target.value; paint(); });
  bindCopyButton($("#copyBtn"), () => fillMessage(s.message), s.copyLabel || "Copiar mensagem");
  s.next && DecisionPanel($("#decision"), s.next);
  $("#toCrm").addEventListener("click", () => openLeadForm(null, {
    name: state.contactName.trim(),
    stage: s.category==="prospeccao" ? "contatado" : id==="f-proposta"||id==="o-proposta" ? "proposta" : "conversando"
  }));
};

pages.crm = () => {
  const today = todayISO();
  const counts = Object.fromEntries(STAGES.map(st=>[st.id, state.leads.filter(l=>l.stage===st.id).length]));
  const head = `<div class="crm-head">
      ${Header("📋 CRM","Acompanhe seus leads e saiba quem precisa de atenção.")}
      ${state.leads.length?`<button class="btn btn-primary" type="button" data-add>＋ Adicionar lead</button>`:""}
    </div>`;
  if(!state.leads.length){
    return head + EmptyState({emoji:"📋", title:"Nenhum lead cadastrado", text:"Adicione o primeiro lead para acompanhar cada conversa até o fechamento.", action:`<button class="btn btn-primary" type="button" data-add>＋ Adicionar lead</button>`});
  }
  const LeadCard = l => {
    let datePill = "";
    if(l.next){
      const cls = l.next < today ? "late" : l.next === today ? "today" : "";
      const txt = l.next < today ? `Atrasado: ${fmtDate(l.next)}` : l.next === today ? "Contato hoje" : `Próximo contato: ${fmtDate(l.next)}`;
      datePill = `<span class="pill ${cls}">${txt}</span>`;
    }
    const digits = (l.phone||"").replace(/\D/g,"");
    const wa = digits ? `https://wa.me/${digits.length<=11?"55"+digits:digits}` : "";
    return `<article class="lead" draggable="true" data-id="${l.id}">
      <div class="lead-top"><h3>${esc(l.name)}</h3></div>
      ${l.company?`<div class="co">${esc(l.company)}</div>`:""}
      ${l.note?`<p class="note">${esc(l.note)}</p>`:""}
      ${(wa||datePill)?`<div class="lead-meta">${wa?`<a class="pill wa" href="${wa}" target="_blank" rel="noopener" aria-label="Abrir WhatsApp de ${esc(l.name)}">WhatsApp</a>`:""}${datePill}</div>`:""}
      <div class="lead-foot">
        <label class="sr-only" for="st-${l.id}">Mover ${esc(l.name)} para a etapa</label>
        <select id="st-${l.id}" data-move="${l.id}">${STAGES.map(s=>`<option value="${s.id}" ${s.id===l.stage?"selected":""}>${s.label}</option>`).join("")}</select>
        <button class="icon-btn" type="button" data-edit="${l.id}" aria-label="Editar ${esc(l.name)}">Editar</button>
        <button class="icon-btn del" type="button" data-del="${l.id}" aria-label="Excluir ${esc(l.name)}">Excluir</button>
      </div>
    </article>`;
  };
  return head + `
    <div class="stage-tabs" aria-label="Etapas do funil">
      ${STAGES.map(s=>`<button class="stage-tab" type="button" data-tab="${s.id}" aria-pressed="${s.id===state.crmCol}">${s.label}<span class="n">${counts[s.id]}</span></button>`).join("")}
    </div>
    <div class="board">
      ${STAGES.map(s=>{
        const list = state.leads.filter(l=>l.stage===s.id);
        return `<section class="col ${s.id===state.crmCol?"active":""}" data-col="${s.id}" aria-label="${s.label}">
          <div class="col-head"><span class="dot s-${s.id}"></span>${s.label}<span class="n">${list.length}</span></div>
          <div class="col-list">${list.length?list.map(LeadCard).join(""):`<div class="col-empty">Nenhum lead em ${s.label.toLowerCase()}.</div>`}</div>
        </section>`;
      }).join("")}
    </div>`;
};
pages.crm.mount = () => {
  const main = $("#main");
  $$("[data-add]", main).forEach(b=>b.addEventListener("click", ()=>openLeadForm(null, { stage: state.crmCol })));
  $$("[data-tab]", main).forEach(b=>b.addEventListener("click", ()=>{
    state.crmCol = b.dataset.tab; storage.set(KEYS.col, state.crmCol);
    $$("[data-tab]", main).forEach(x=>x.setAttribute("aria-pressed", x===b));
    $$(".col", main).forEach(c=>c.classList.toggle("active", c.dataset.col===state.crmCol));
  }));
  const move = (id, stage) => {
    const l = state.leads.find(x=>x.id===id); if(!l || l.stage===stage) return;
    l.stage = stage; saveLeads();
    toast(`✓ Movido para ${STAGES.find(s=>s.id===stage).label}`);
    render(false);
  };
  $$("[data-move]", main).forEach(sel=>sel.addEventListener("change", e=>move(sel.dataset.move, e.target.value)));
  $$("[data-edit]", main).forEach(b=>b.addEventListener("click", ()=>openLeadForm(state.leads.find(l=>l.id===b.dataset.edit))));
  $$("[data-del]", main).forEach(b=>b.addEventListener("click", ()=>{
    const l = state.leads.find(x=>x.id===b.dataset.del);
    confirmDialog(`O lead <strong>${esc(l.name)}</strong> será excluído. Essa ação não pode ser desfeita.`, "Excluir lead", ()=>{
      state.leads = state.leads.filter(x=>x.id!==l.id); saveLeads(); toast("Lead excluído"); render(false);
    });
  }));
  // Arrastar e soltar (desktop)
  $$(".lead", main).forEach(card=>{
    card.addEventListener("dragstart", e=>{ e.dataTransfer.setData("text/plain", card.dataset.id); e.dataTransfer.effectAllowed="move"; card.classList.add("dragging"); });
    card.addEventListener("dragend", ()=>card.classList.remove("dragging"));
  });
  $$(".col", main).forEach(col=>{
    col.addEventListener("dragover", e=>{ e.preventDefault(); col.classList.add("drop"); });
    col.addEventListener("dragleave", e=>{ if(!col.contains(e.relatedTarget)) col.classList.remove("drop"); });
    col.addEventListener("drop", e=>{ e.preventDefault(); col.classList.remove("drop"); move(e.dataTransfer.getData("text/plain"), col.dataset.col); });
  });
};

pages.guia = () => {
  const steps = [
    { t:"Escolha uma estratégia de aquisição." },
    { t:"Use a prospecção para iniciar conversas.", href:"#/prospeccao", l:"Abrir prospecção" },
    { t:"Use os scripts de vendas para conduzir a oportunidade.", href:"#/vendas", l:"Abrir vendas" },
    { t:"Registre o lead no CRM.", href:"#/crm", l:"Abrir CRM" },
    { t:"Faça os follow-ups.", href:"#/followup", l:"Abrir follow-ups" },
    { t:"Acompanhe seus resultados.", href:"#/crm", l:"Ver funil no CRM" }
  ];
  return `
  ${Header("📚 Como usar seu Kit","Seis passos. Menos de um minuto para entender.")}
  <ol class="steps">${steps.map((s,i)=>`<li><span class="n" aria-hidden="true">${i+1}</span><div><strong><span class="sr-only">Passo ${i+1}: </span>${s.t}</strong>${s.href?`<a href="${s.href}">${s.l}</a>`:""}</div></li>`).join("")}</ol>

  <section class="panel" aria-labelledby="pTitle">
    <h2 id="pTitle">Personalize suas mensagens</h2>
    <p>Esses dados preenchem automaticamente [SEU NOME] e [ESCRITÓRIO] em todos os scripts.</p>
    <form id="prefsForm">
      <div class="row2">
        <div class="field"><label for="pNome">Seu nome</label><input id="pNome" name="seuNome" autocomplete="name" value="${esc(state.prefs.seuNome)}" placeholder="Ex.: Ana"></div>
        <div class="field"><label for="pEsc">Nome do escritório</label><input id="pEsc" name="escritorio" autocomplete="organization" value="${esc(state.prefs.escritorio)}" placeholder="Ex.: Silva Contabilidade"></div>
      </div>
      <button class="btn btn-primary" type="submit">Salvar dados</button>
    </form>
  </section>

  <section class="panel" aria-labelledby="rTitle">
    <h2 id="rTitle">Dados salvos neste aparelho</h2>
    <p>Seus leads e preferências ficam guardados neste navegador. Para começar do zero, apague tudo.</p>
    <button class="btn btn-ghost" type="button" id="resetAll">Apagar todos os dados</button>
  </section>`;
};
pages.guia.mount = () => {
  $("#prefsForm").addEventListener("submit", e=>{
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(e.target).entries());
    state.prefs = { seuNome: fd.seuNome.trim(), escritorio: fd.escritorio.trim() };
    savePrefs(); toast("✓ Dados salvos");
  });
  $("#resetAll").addEventListener("click", ()=>confirmDialog("Todos os leads e preferências serão apagados deste aparelho.", "Apagar tudo", ()=>{
    Object.values(KEYS).forEach(k=>storage.remove(k));
    state.leads=[]; state.prefs={seuNome:"",escritorio:""}; state.crmCol="novo";
    toast("Dados apagados"); render(false);
  }));
};

/* =====================================================================
   6. ROTEADOR
   ===================================================================== */
let firstRender = true;
function render(resetScroll = true){
  const path = location.hash.replace(/^#\/?/, "");
  const [a, b] = path.split("/");
  let html, mount, section = "inicio", wide = false;

  if(!a){ html = pages.home(); }
  else if(a==="prospeccao"){ html = pages.prospeccao(); section = a; }
  else if(a==="vendas" && b==="objecoes"){ html = pages.objecoes(); section = "vendas"; }
  else if(a==="vendas"){ html = pages.vendas(); section = a; }
  else if(a==="followup"){ html = pages.followup(); section = a; }
  else if(a==="crm"){ html = pages.crm(); mount = pages.crm.mount; section = a; wide = true; }
  else if(a==="guia"){ html = pages.guia(); mount = pages.guia.mount; section = a; }
  else if(a==="s"){ html = pages.script(b); mount = () => pages.script.mount(b); section = SCRIPTS[b]?.category || "inicio"; }
  else { html = pages.home(); }

  Nav(section);
  const main = $("#main");
  main.classList.toggle("wide", wide);
  main.innerHTML = `<div class="view">${html}</div>`;
  mount && mount();

  if(resetScroll){
    window.scrollTo(0, 0);
    if(!firstRender){ const h = $("h1", main); h && h.focus({preventScroll:true}); }
  }
  firstRender = false;
}
window.addEventListener("hashchange", () => render());
render();
